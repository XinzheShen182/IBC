1. go.mod 参考fabric-2.2的版本 修改
